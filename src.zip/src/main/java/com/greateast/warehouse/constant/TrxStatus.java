package com.greateast.warehouse.constant;

public enum TrxStatus {
    PENDING,
    SUCCESS,
    CANCELLED,
}
