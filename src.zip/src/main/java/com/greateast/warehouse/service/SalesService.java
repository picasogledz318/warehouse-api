
package com.greateast.warehouse.service;

import com.greateast.warehouse.constant.TrxCode;
import com.greateast.warehouse.constant.TrxStatus;
import com.greateast.warehouse.model.entity.Item;
import com.greateast.warehouse.model.entity.Payment;
import com.greateast.warehouse.model.entity.Sales;
import com.greateast.warehouse.model.entity.Variant;
import com.greateast.warehouse.model.request.PaymentRequest;
import com.greateast.warehouse.model.request.SalesRequest;
import com.greateast.warehouse.model.response.BaseResponseDto;
import com.greateast.warehouse.repository.SalesRepository;
import com.greateast.warehouse.repository.VariantRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

/**
 * Service responsible for sales logic.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class SalesService {

    private final SalesRepository salesRepository;
    private final StockService stockService;
    private final VariantService variantService;
    private final VariantRepository variantRepository;



    /**
     * Sales order from stock in warehouse.
     * return if stock sufficient then return salesResponse with transaction status pending (waiting for payment)
     * Throws exception if stock is insufficient.
     */
    public BaseResponseDto<Sales> salesOrder(SalesRequest salesRequest) {
        BaseResponseDto<Sales> resp = new BaseResponseDto<>();
        BaseResponseDto<Variant> varResp = new BaseResponseDto<>();
        try{
            BaseResponseDto<Variant> validateResp = stockService.validateStock(salesRequest.getItemId() ,salesRequest.getVariantId(), salesRequest.getOrderQuantity());
            //validate if stock available then proceed for sales
            if(validateResp.getCode().equalsIgnoreCase(TrxCode.TRX_STOCK_AVAILABLE.code())){
                Sales sales = new Sales();
                BeanUtils.copyProperties(salesRequest, sales);
                sales.setTrxStatus(TrxStatus.PENDING.name());
                Variant targetVariant = validateResp.getData();
                //auto calculate total order price from variant
                BigDecimal totalOrderPrice = targetVariant.getSalesPrice().multiply((BigDecimal.valueOf(salesRequest.getOrderQuantity())));
                sales.setTotalOrderPrice(totalOrderPrice);
                sales = salesRepository.save(sales);
                log.info("Sales saved:{}",sales);

                //return sales response
                resp.setCode(TrxCode.TRX_PENDING.code());
                resp.setData(sales);
                resp.setErrors(null);
                resp.setMessage(TrxCode.TRX_PENDING.description());
            } else {
                resp.setCode(validateResp.getCode());
                resp.setMessage(validateResp.getMessage());
                resp.setData(null);
                resp.setErrors(null);
            }
        }catch (Exception err){
            log.error("Error sales:{}, trace:{}",err.getMessage(), err.getStackTrace());
            throw new RuntimeException("Error sales:"+err.getMessage());
        }

        return  resp;
    }


    /**
     * Retrieve all sales with pagination.
     */
    public BaseResponseDto<Page<Sales>> findAll(int page, int size) {

        BaseResponseDto<Page<Sales>> resp = new BaseResponseDto<>();
        try{
            Page<Sales> pageSales = salesRepository.findAll(PageRequest.of(page, size));
            resp.setCode(TrxCode.TRX_OK.code());
            resp.setData(pageSales);
            resp.setErrors(null);
            if(pageSales != null && !pageSales.isEmpty()) resp.setMessage("All Sales");
            else resp.setMessage("No Data");
        }catch (Exception err){
            log.error("Error find all sales:{}, trace:{}",err.getMessage(), err.getStackTrace());
            throw new RuntimeException("Error find all sales:"+err.getMessage());
        }
        return resp ;
    }

    /**
     * Find sales by id.
     */
    public BaseResponseDto<Sales> findById(long id) {
        BaseResponseDto<Sales> resp = new BaseResponseDto<>();
        boolean isSalesExist = existsById(id);
        if(isSalesExist){
            resp.setCode(TrxCode.TRX_OK.code());
            resp.setData(salesRepository.findById(id).get());
            resp.setErrors(null);
            resp.setMessage("Data Found!");
        } else {
            resp.setCode(TrxCode.TRX_NOT_FOUND.code());
            resp.setData(null);
            resp.setErrors(null);
            resp.setMessage(TrxCode.TRX_NOT_FOUND.description());
        }

        return resp;
    }

    /**
     * Check sales existence by id.
     */
    public Boolean existsById(long id) {
        return salesRepository.existsById(id);
    }


}
